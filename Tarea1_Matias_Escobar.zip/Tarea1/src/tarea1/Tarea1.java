package tarea1;
import java.util.Date;
import java.util.ArrayList;
import java.util.Scanner;

public class Tarea1 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        for(int i=0; i<4; i++) {
            int index = i+1;
            System.out.println("Cliente "+index+", ingrese su nombre, rut, direccion y cantidad de articulos a comprar: ");
            String nombre_cl = entrada.nextLine();
            String rut_cl = entrada.nextLine();
            String direccion_cl = entrada.nextLine();
            int cantidad_cl = entrada.nextInt();
            Cliente cl = new Cliente(nombre_cl,rut_cl,direccion_cl);
            OrdenCompra oc = new OrdenCompra("En proceso", cantidad_cl);
            System.out.println("El monto total a pagar es: $"+oc.calcPrecio());
            System.out.println("Cliente "+index+", elija la opcion con la que prefiere pagar:\n1. Transferencia 2. Tarjeta 3. Efectivo");
            int opcion = entrada.nextInt();
            oc.setPago(opcion);
            System.out.println("Gracias por su compra");
            System.out.println("Ingrese la opcion que prefiera:\n1. Boleta 2. Factura");
            int bolFac = entrada.nextInt();
            oc.setDoc(bolFac);
            DocTributario doc = oc.getDoc();
            System.out.println(doc.toString());
            System.out.println("Datos del cliente: ");
            System.out.println(cl.toString());
            System.out.println("Monto total pagado: $"+oc.calcIVA()+"\n"+"Monto total sin IVA: $"+oc.calcPrecioSinIVA()+"\n"+"Peso total productos: "+oc.calcPeso()+" kg");
            oc.setEstado();
            System.out.println(oc.getEstado());
        }
    }
}
class Cliente {
    private String nombre;
    private String rut;
    private Direccion dir;
    public Cliente(String nombre, String rut, String direccion) {
        this.nombre = nombre;
        this.rut = rut;
        dir = new Direccion(direccion);
    }
    public String toString() {
        return ("Nombre cliente: "+nombre+"\n"+"Rut cliente: "+rut+"\n"+"Direccion cliente: "+dir.toString());
    }
}
class Direccion {
    private String direccion;
    public Direccion(String direccion) {
        this.direccion = direccion;
    }
    public String toString() {
        return direccion;
    }
}
class OrdenCompra {
    private Date fecha;
    private String estado;
    private DetalleOrden detOrden;
    private int cantidad;
    private DocTributario doc;
    private Direccion dir_local = new Direccion("Direccion_LocalVenta");
    private Pago pago;
    public OrdenCompra(String estado, int cantidad) {
        fecha = new Date();
        this.estado = estado;
        this.cantidad = cantidad;
        detOrden = new DetalleOrden(this.cantidad);
    }
    public float calcPrecioSinIVA() {
        float precio = 0;
        for(int i=0; i<cantidad; i++) {
            precio += detOrden.calcPrecioSinIVA(i);
        }
        return precio;
    }
    public float calcIVA() {
        float precio = 0;
        for(int i=0; i<cantidad; i++) {
            precio += detOrden.calcIVA(i);
        }
        return precio;
    }
    public float calcPrecio() {
        float precio = 0;
        for(int i=0; i<cantidad; i++) {
            precio += detOrden.calcPrecio(i);
        }
        return precio;
    }
    public float calcPeso() {
        float peso = 0;
        for(int i=0; i<cantidad; i++) {
            peso += detOrden.calcPeso(i);
        }
        return peso;
    }
    public void setPago(int opcion) {
        Scanner entrada = new Scanner(System.in);
        switch (opcion) {
            case 1: pago = new Transferencia(this.calcPrecio(),fecha);
                    System.out.println("Eligió transferencia, aqui tiene los datos: ");
                    System.out.println(pago.toString());
                    break;
            case 2: System.out.println("Eligió tarjeta, por favor ingrese su tipo de tarjeta: ");
                    String tarj = entrada.nextLine();
                    pago = new Tarjeta(this.calcPrecio(),fecha,tarj);
                    System.out.println(pago.toString());
                    break;
            case 3: System.out.println("Eligió efectivo, por favor ingrese con cuanto va a pagar: ");        
                    float pago_efectivo = entrada.nextFloat();
                    pago = new Efectivo(this.calcPrecio(),fecha,pago_efectivo);
                    System.out.println("Su vuelto es: $"+pago.toString());
                    break;
        }
    }
    public void setEstado() {
        this.estado = "Compra finalizada";
    }
    public String getEstado() {
        return estado;
    }
    public DocTributario getDoc() {
        return doc;
    }
    public void setDoc(int bolFac) {
        switch (bolFac) {
            case 1: doc = new Boleta(fecha,dir_local,"Rut_local"); break;
            case 2: doc = new Factura(fecha,dir_local,"Rut_local"); break;
        }
    }
}
abstract class DocTributario {
    private Direccion dir;
    private String rut;
    private Date fecha;
    public DocTributario(Date fecha, Direccion dir, String rut) {
        this.fecha = fecha;
        this.dir = dir;
        this.rut = rut;
    }
    public abstract String toString();
    public String getDireccion() {
        return dir.toString();
    }
    public String getRut() {
        return rut;
    }
    public Date getFecha() {
        return fecha;
    }
}
class Boleta extends DocTributario {
    public Boleta(Date fecha, Direccion dir, String rut) {
        super(fecha, dir, rut);
    }
    public String toString() {
        return ("Boleta de venta: \n"+"Direccion Local: "+super.getDireccion()+"\n"+"Rut Local: "+super.getRut()+"\n"+"Fecha: "+super.getFecha());
    }
}
class Factura extends DocTributario {
    public Factura(Date fecha, Direccion dir, String rut) {
        super(fecha, dir, rut);
    }
    public String toString() {
        return ("Factura de venta: \n"+"Direccion Local: "+super.getDireccion()+"\n"+"Rut Local: "+super.getRut()+"\n"+"Fecha: "+super.getFecha());
    }
}
class DetalleOrden {
    private int cantidad;
    private ArrayList<Articulo> al;
    public DetalleOrden(int cantidad) {
        this.cantidad = cantidad;
        al = new ArrayList<Articulo>();
        Scanner entrada = new Scanner(System.in);
        for(int i=0; i<this.cantidad; i++) {
            int index = i+1;
            System.out.println("Indique, del 1 al 5, cual quiere que sea su articulo numero "+index+": ");
            int num = entrada.nextInt();
            switch (num) {
                case 1: Articulo a1 = new Articulo("Articulo1","DescripcionA1",(float)1.45,1500); al.add(a1); break;
                case 2: Articulo a2 = new Articulo("Articulo2","DescripcionA2",(float)3.61,1000); al.add(a2); break;
                case 3: Articulo a3 = new Articulo("Articulo3","DescripcionA3",(float)2.59,2300); al.add(a3); break;
                case 4: Articulo a4 = new Articulo("Articulo4","DescripcionA4",(float)6.12,3400); al.add(a4); break;
                case 5: Articulo a5 = new Articulo("Articulo5","DescripcionA5",(float)4.06,2100); al.add(a5); break;
            }
        }
    }
    public float calcPrecio(int pos) {
        Articulo art = al.get(pos);
        float precio = art.getPrecio();
        return precio;
    }
    public float calcPrecioSinIVA(int pos) {
        Articulo art = al.get(pos);
        float precio = art.getPrecio();
        float precioSinIVA = (float)(precio*81)/100;
        return precioSinIVA;
    }
    public float calcIVA(int pos) {
        Articulo art = al.get(pos);
        float precio = art.getPrecio();
        return precio;
    }
    public float calcPeso(int pos) {
        Articulo art = al.get(pos);
        float peso = art.getPeso();
        return peso;
    }
}
class Articulo {
    private float peso;
    private String nombre;
    private String descripcion;
    private float precio;
    public Articulo(String nombre, String descripcion, float peso, float precio) {
        this.peso = peso;
        this.nombre  = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
    }
    public float getPeso() {
        return peso;
    }
    public float getPrecio() {
        return precio;
    }
    public String getNombre() {
        return nombre;
    }
    public String getDescripcion() {
        return descripcion;
    }
}
abstract class Pago {
    private float monto;
    private Date fecha;
    public Pago(float monto, Date fecha) {
        this.monto = monto;
        this.fecha = fecha;
    }
    public float getMonto() {
        return monto;
    }
    public abstract String toString();
}
class Efectivo extends Pago {
    private float vuelto = 0;
    private float pago_efectivo = 0;
    public Efectivo(float monto, Date fecha, float pago_efectivo) {
        super(monto, fecha);
        this.pago_efectivo = pago_efectivo;
        this.calcDevolucion();
    }
    public void calcDevolucion() {
        vuelto = pago_efectivo - super.getMonto();
    }
    public String toString() {
        return ""+vuelto;
    }
}
class Transferencia extends Pago {
    private String banco;
    private String numCuenta;
    public Transferencia(float monto, Date fecha) {
        super(monto, fecha);
        banco = "Banco_Local";
        numCuenta = "NumCuenta_Banco";
    }
    public String toString() {
        return "Banco: "+banco+", Numero de Cuenta: "+numCuenta;
    }
}
class Tarjeta extends Pago {
    private String tipo;
    private String numTransaccion;
    public Tarjeta(float monto, Date fecha, String tarjeta) {
        super(monto, fecha);
        tipo = tarjeta;
        numTransaccion = "Nro_Transaccion";
    }
    public String toString() {
        return "Numero de transaccion: "+numTransaccion;
    }
}